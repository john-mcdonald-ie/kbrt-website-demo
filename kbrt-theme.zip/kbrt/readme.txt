=== KBRT ===
Contributors: John McDonald
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Block theme for the Kevin Bell Repatriation Trust.

== Description ==

Built mobile first around three journeys, in this order: getting help, giving, and trust.
The phone number sits at the top of every page, and a Call / Donate bar stays on screen on phones.
Sections meet on clean, straight colour changes. Colours come from the KBRT jersey, the 2026 fact sheet and the goldfinch. Body text is Atkinson
Hyperlegible Next, chosen for readers with low vision. Text and controls meet WCAG 2.2 AA contrast.

Built in features:

* Structured data (schema.org NGO with both charity numbers, WebSite, and FAQPage generated
  automatically from any Details blocks on a page).
* /llms.txt served automatically: a short factual summary for AI assistants.
* Open Graph and Twitter card tags with a branded share image, when no SEO plugin is active.
* "Wherever you are" panel: Newry time beside the visitor's own time, and one-tap sharing of
  the help page and phone number with family by WhatsApp or email.
* Meta description taken from the page excerpt when no SEO plugin is active.
* Logo and site icon imported automatically on activation.
* Fonts bundled in the theme (no calls to Google), so no font cookies or third-party requests.

== Installation on WordPress.com ==

1. Appearance > Themes > Add new theme > Upload theme. Choose kbrt.zip and activate.
   The KBRT logo and goldfinch site icon are added to the media library and set automatically.
2. Create these pages. For each one: Pages > Add new, pick the matching pattern from
   "Choose a pattern" (KBRT: full pages), set Template to "Designed page (no page title)",
   and write a one-sentence excerpt (it becomes the search description).
   * Get help now, slug get-help, pattern "Page: Get help now"
   * Donate, slug donate, pattern "Page: Donate"
   * Our story, slug our-story, pattern "Page: Our story and impact"
   * Contact, slug contact, pattern "Page: Contact"
   * News, slug news, then Settings > Reading > Posts page = News
3. The home page uses the theme's front page design automatically.
4. Settings > General: set the tagline to one plain sentence, for example
   "We help bereaved families in all 32 counties of Ireland bring home loved ones who die abroad."
5. Forms: on Get help and Contact, replace the "Form goes here" paragraph with a Form block
   (Jetpack Form, included on WordPress.com). The paragraph lists the fields to add.
6. Donations: euro gifts go to the Trust's iDonate page (one-off or monthly). Sterling gifts use
   the Trust's existing Gravity Forms + Stripe form: install Gravity Forms and its Stripe add-on,
   import form 3 from the old site, and place it where "Sterling donation form goes here" appears.
   PayPal, JustGiving and iDonate fundraising links are already in place.
7. Shop (optional): install WooCommerce, recreate the five products, then in Appearance > Editor >
   Templates > Product Catalogue insert the "Shop: opening banner" pattern above the products.
8. Redirects from the old site (use the Redirection plugin or the host's redirect tool):
   /about-kbrt/ to /our-story/, /donations/ to /donate/, /fundraising/ to /donate/#fundraise,
   /sitemap/ to /. Keep the old news post slugs if the posts are migrated.

== Content still to supply (shown in square brackets on the pages) ==

* Office opening hours and out-of-hours arrangements
* Referral process for funeral directors, embassies and insurers
* Gift Aid declaration wording (UK) and Irish tax relief wording, once eligibility is confirmed
* Shop delivery costs and returns policy
* A WhatsApp Business number, if the Trust wants a WhatsApp button (set 'whatsapp' in kbrt_facts())
* Link to the annual report and accounts
* Privacy, cookie, accessibility and shop terms pages (linked from the footer)
* A higher resolution photograph of Kevin, if the family is happy to provide one

== Updating the facts ==

Headline figures appear in the patterns (Impact figures, Our story) and in kbrt_facts() in
functions.php, which feeds the structured data, llms.txt and the mobile bar. Update both together.

== Credits ==

Fonts: Newsreader, Atkinson Hyperlegible Next and Josefin Sans, SIL Open Font License 1.1
(licence files in assets/fonts). Photographs and logo: Kevin Bell Repatriation Trust, from the
KBRT 2026 fact sheet and existing website. Confirm the licence of the landscape photographs
for web use before launch.
