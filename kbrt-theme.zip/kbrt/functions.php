<?php
/**
 * KBRT theme functions.
 *
 * @package kbrt
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KBRT_VERSION', '1.1.3' );

/**
 * Charity facts used by structured data, llms.txt and the mobile action bar.
 * Change them here, or filter 'kbrt_facts' from a plugin, rather than editing templates.
 *
 * @return array
 */
function kbrt_facts() {
	$facts = array(
		'name'            => 'Kevin Bell Repatriation Trust',
		'short_name'      => 'KBRT',
		'phone'           => '+44 28 3083 3311',
		'phone_display'   => '+44 (0)28 3083 3311',
		'phone_roi'       => '048 3083 3311',
		'email'           => 'info@kevinbellrepatriationtrust.com',
		'street'          => 'Unit 7 Whitegates Business Park, Killeavy Road',
		'locality'        => 'Newry',
		'region'          => 'Co. Down',
		'postcode'        => 'BT35 6UA',
		'country'         => 'GB',
		'ccni'            => 'NIC100314',
		'rcn'             => '20102937',
		'founded'         => '2013',
		'repatriations'   => '2,612',
		'facts_as_of'     => '2026-10',
		'countries'       => '88',
		'cost_range'      => 'about €1,600 to €18,000',
		'cost_average'    => 'about €6,000 to €7,000',
		'facebook'        => 'https://www.facebook.com/kevinbellrepatriationtrust/',
		'x'               => 'https://twitter.com/kbrt2013',
		'help_path'       => '/get-help/',
		'idonate'         => 'https://www.idonate.ie/cause/kbrt',
		'idonate_fundraise' => 'https://www.idonate.ie/createfundraiser?chid=1471&event=bycharity&currency=EUR',
		'justgiving_fundraise' => 'https://www.justgiving.com/fundraising-page/creation/initiate-authenticated-page-creation-process?pcId=d200e7d5-ba5b-47ec-8835-7ceae50ea0a5',
		'paypal'          => 'https://www.paypal.com/donate?hosted_button_id=SCDQ8S6ERXLJJ',
		'gbp_form'        => '#donate-sterling',
		'whatsapp'        => '',
		'donate_path'     => '/donate/',
	);
	return apply_filters( 'kbrt_facts', $facts );
}

/**
 * Theme setup.
 */
function kbrt_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_editor_style( 'style.css' );
	add_post_type_support( 'page', 'excerpt' );
}
add_action( 'after_setup_theme', 'kbrt_setup' );

/**
 * Front-end stylesheet.
 */
function kbrt_enqueue() {
	wp_enqueue_style( 'kbrt-style', get_stylesheet_uri(), array(), KBRT_VERSION );
}
add_action( 'wp_enqueue_scripts', 'kbrt_enqueue' );

/**
 * Preload the display font so headings do not shift on slow mobile connections.
 */
function kbrt_preload_fonts() {
	$href = get_theme_file_uri( 'assets/fonts/newsreader-latin-opsz-normal.woff2' );
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $href ) );
}
add_action( 'wp_head', 'kbrt_preload_fonts', 1 );

/**
 * Block styles and pattern categories.
 */
function kbrt_register_block_bits() {
	register_block_style(
		'core/button',
		array(
			'name'  => 'yellow',
			'label' => __( 'Goldfinch yellow', 'kbrt' ),
		)
	);
	register_block_pattern_category( 'kbrt-pages', array( 'label' => __( 'KBRT: full pages', 'kbrt' ) ) );
	register_block_pattern_category( 'kbrt-sections', array( 'label' => __( 'KBRT: sections', 'kbrt' ) ) );
}
add_action( 'init', 'kbrt_register_block_bits' );

/**
 * On activation, import the KBRT logo and goldfinch icon into the media library
 * and set them as the site logo and site icon, unless the site already has them.
 */
function kbrt_import_brand_assets() {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$import = function ( $relative, $title ) {
		$path = get_theme_file_path( $relative );
		if ( ! file_exists( $path ) ) {
			return 0;
		}
		$tmp = wp_tempnam( basename( $path ) );
		if ( ! $tmp || ! copy( $path, $tmp ) ) {
			return 0;
		}
		$file = array(
			'name'     => basename( $path ),
			'tmp_name' => $tmp,
		);
		$id = media_handle_sideload( $file, 0, $title );
		if ( is_wp_error( $id ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return 0;
		}
		return (int) $id;
	};

	if ( ! get_theme_mod( 'custom_logo' ) ) {
		$logo = $import( 'assets/images/kbrt-logo.png', 'KBRT, Kevin Bell Repatriation Trust' );
		if ( $logo ) {
			set_theme_mod( 'custom_logo', $logo );
			update_post_meta( $logo, '_wp_attachment_image_alt', 'KBRT, Kevin Bell Repatriation Trust' );
		}
	}
	if ( ! get_option( 'site_icon' ) ) {
		$icon = $import( 'assets/images/site-icon-512.png', 'KBRT goldfinch icon' );
		if ( $icon ) {
			update_option( 'site_icon', $icon );
		}
	}
}
add_action( 'after_switch_theme', 'kbrt_import_brand_assets' );

/**
 * Structured data: the charity on every page, FAQs where a page has them.
 */
function kbrt_structured_data() {
	$f    = kbrt_facts();
	$home = home_url( '/' );
	$logo = get_theme_file_uri( 'assets/images/kbrt-logo.png' );

	$org = array(
		'@type'         => 'NGO',
		'@id'           => $home . '#organisation',
		'name'          => $f['name'],
		'alternateName' => $f['short_name'],
		'url'           => $home,
		'logo'          => $logo,
		'foundingDate'  => $f['founded'],
		'description'   => 'Northern Ireland and Irish registered charity that gives bereaved families in all 32 counties of Ireland financial assistance, logistical support and advice to repatriate loved ones who die abroad in sudden or tragic circumstances.',
		'telephone'     => $f['phone'],
		'email'         => $f['email'],
		'address'       => array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $f['street'],
			'addressLocality' => $f['locality'],
			'addressRegion'   => $f['region'],
			'postalCode'      => $f['postcode'],
			'addressCountry'  => $f['country'],
		),
		'areaServed'    => array(
			array( '@type' => 'Country', 'name' => 'Ireland' ),
			array( '@type' => 'AdministrativeArea', 'name' => 'Northern Ireland' ),
		),
		'identifier'    => array(
			array( '@type' => 'PropertyValue', 'propertyID' => 'Charity Commission for Northern Ireland', 'value' => $f['ccni'] ),
			array( '@type' => 'PropertyValue', 'propertyID' => 'Charities Regulator (Ireland) RCN', 'value' => $f['rcn'] ),
		),
		'founder'       => array(
			array( '@type' => 'Person', 'name' => 'Colin Bell' ),
			array( '@type' => 'Person', 'name' => 'Eithne Bell' ),
		),
		'contactPoint'  => array(
			array(
				'@type'             => 'ContactPoint',
				'contactType'       => 'Bereaved families needing repatriation support',
				'telephone'         => $f['phone'],
				'email'             => $f['email'],
				'areaServed'        => array( 'IE', 'GB' ),
				'availableLanguage' => array( 'en' ),
			),
		),
		'sameAs'        => array( $f['facebook'], $f['x'] ),
	);

	$graph = array(
		$org,
		array(
			'@type'     => 'WebSite',
			'@id'       => $home . '#website',
			'url'       => $home,
			'name'      => $f['name'],
			'publisher' => array( '@id' => $home . '#organisation' ),
			'inLanguage' => 'en-GB',
		),
	);

	// FAQPage from core/details blocks on the current page.
	if ( is_singular() ) {
		$post = get_post();
		if ( $post ) {
			$questions = array();
			foreach ( kbrt_flatten_blocks( parse_blocks( $post->post_content ) ) as $block ) {
				if ( 'core/details' !== $block['blockName'] ) {
					continue;
				}
				$html = render_block( $block );
				if ( ! preg_match( '#<summary[^>]*>(.*?)</summary>#s', $html, $m ) ) {
					continue;
				}
				$question = trim( wp_strip_all_tags( $m[1] ) );
				$answer   = trim( wp_strip_all_tags( preg_replace( '#<summary[^>]*>.*?</summary>#s', '', $html ) ) );
				if ( $question && $answer ) {
					$questions[] = array(
						'@type'          => 'Question',
						'name'           => $question,
						'acceptedAnswer' => array( '@type' => 'Answer', 'text' => preg_replace( '/\s+/', ' ', $answer ) ),
					);
				}
			}
			if ( $questions ) {
				$graph[] = array(
					'@type'      => 'FAQPage',
					'@id'        => get_permalink( $post ) . '#faq',
					'mainEntity' => $questions,
				);
			}
		}
	}

	$data = array(
		'@context' => 'https://schema.org',
		'@graph'   => $graph,
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'kbrt_structured_data', 20 );

/**
 * Flatten nested blocks.
 *
 * @param array $blocks Parsed blocks.
 * @return array
 */
function kbrt_flatten_blocks( $blocks ) {
	$out = array();
	foreach ( $blocks as $block ) {
		// Expand pattern references so FAQs inside inserted patterns are found.
		if ( 'core/pattern' === $block['blockName'] && ! empty( $block['attrs']['slug'] ) && class_exists( 'WP_Block_Patterns_Registry' ) ) {
			$pattern = WP_Block_Patterns_Registry::get_instance()->get_registered( $block['attrs']['slug'] );
			if ( $pattern && ! empty( $pattern['content'] ) ) {
				$out = array_merge( $out, kbrt_flatten_blocks( parse_blocks( $pattern['content'] ) ) );
			}
			continue;
		}
		$out[] = $block;
		if ( ! empty( $block['innerBlocks'] ) ) {
			$out = array_merge( $out, kbrt_flatten_blocks( $block['innerBlocks'] ) );
		}
	}
	return $out;
}

/**
 * Meta description from the page excerpt, only when no SEO plugin is handling it.
 */
function kbrt_meta_description() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || class_exists( 'Jetpack_SEO_Posts' ) ) {
		return;
	}
	$desc = '';
	if ( is_front_page() ) {
		$desc = get_bloginfo( 'description' );
	} elseif ( is_singular() && has_excerpt() ) {
		$desc = get_the_excerpt();
	}
	if ( $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( wp_trim_words( wp_strip_all_tags( $desc ), 30, '' ) ) );
	}
}
add_action( 'wp_head', 'kbrt_meta_description', 2 );

/**
 * Serve /llms.txt: a short, factual summary for AI assistants and crawlers.
 */
function kbrt_llms_txt() {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '';
	if ( '/llms.txt' !== $path ) {
		return;
	}
	$f    = kbrt_facts();
	$home = untrailingslashit( home_url() );
	$text = "# {$f['name']} ({$f['short_name']})\n\n"
		. "> A registered charity in Northern Ireland ({$f['ccni']}) and Ireland (RCN {$f['rcn']}), founded in {$f['founded']}. It gives bereaved families in all 32 counties of Ireland financial assistance, practical support and advice to bring home loved ones who die abroad in sudden or tragic circumstances.\n\n"
		. "## Key facts (as of {$f['facts_as_of']})\n\n"
		. "- Repatriations since 2013: {$f['repatriations']}\n"
		. "- Countries families have been helped from: {$f['countries']}\n"
		. "- Typical cost of a repatriation: {$f['cost_range']}; average {$f['cost_average']}\n"
		. "- Families can contact the Trust directly, or Irish embassies and consulates can refer them.\n"
		. "- Help is given regardless of background, religion or the circumstances of the death.\n\n"
		. "## Contact\n\n"
		. "- Phone: {$f['phone_display']} (from the Republic of Ireland: {$f['phone_roi']})\n"
		. "- Email: {$f['email']}\n"
		. "- Address: {$f['street']}, {$f['locality']}, {$f['region']} {$f['postcode']}\n\n"
		. "## Pages\n\n"
		. "- [Get help now]({$home}{$f['help_path']}): what to do when someone dies abroad, how the Trust helps, eligibility and FAQs\n"
		. "- [Donate]({$home}{$f['donate_path']}): ways to support the Trust\n"
		. "- [Our story]({$home}/our-story/): Kevin Bell, the Trust's history, impact and governance\n";
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=utf-8' );
	header( 'Cache-Control: public, max-age=3600' );
	echo $text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain text.
	exit;
}
add_action( 'parse_request', 'kbrt_llms_txt', 0 );

/**
 * Persistent Call / Donate bar on phones.
 */
function kbrt_mobile_bar() {
	$f = kbrt_facts();
	?>
	<nav class="kbrt-mobilebar" aria-label="<?php esc_attr_e( 'Quick actions', 'kbrt' ); ?>">
		<a class="is-call" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $f['phone'] ) ); ?>">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/></svg>
			<?php esc_html_e( 'Call us', 'kbrt' ); ?>
		</a>
		<a class="is-donate" href="<?php echo esc_url( home_url( $f['donate_path'] ) ); ?>"><?php esc_html_e( 'Donate', 'kbrt' ); ?></a>
	</nav>
	<?php
}
add_action( 'wp_footer', 'kbrt_mobile_bar' );

/**
 * Newry time and the visitor's local time, for families calling from abroad.
 */
function kbrt_clock_script() {
	?>
	<script>
	(function () {
		var el = document.querySelector('[data-kbrt-clock]');
		if (!el || !window.Intl) { return; }
		var fmt = function (tz) { return new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', timeZone: tz }).format(new Date()); };
		var local = Intl.DateTimeFormat().resolvedOptions().timeZone;
		var tick = function () {
			el.querySelector('[data-kbrt-newry]').textContent = fmt('Europe/Belfast');
			if (local && ['Europe/Belfast', 'Europe/London', 'Europe/Dublin'].indexOf(local) === -1) {
				el.querySelector('[data-kbrt-local]').textContent = fmt(local) + ' (' + local.split('/').pop().replace(/_/g, ' ') + ')';
				el.querySelector('[data-kbrt-local-wrap]').hidden = false;
			}
		};
		tick();
		setInterval(tick, 30000);
	}());
	</script>
	<?php
}
add_action( 'wp_footer', 'kbrt_clock_script', 20 );

/**
 * Open Graph and Twitter card tags, only when no SEO plugin is handling them.
 */
function kbrt_social_meta() {
	if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || class_exists( 'Jetpack_SEO_Posts' ) || function_exists( 'jetpack_og_tags' ) ) {
		return;
	}
	$title = wp_get_document_title();
	$desc  = is_singular() && has_excerpt() ? get_the_excerpt() : get_bloginfo( 'description' );
	$url   = is_singular() ? get_permalink() : home_url( add_query_arg( array() ) );
	$image = is_singular() && has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'large' ) : get_theme_file_uri( 'assets/images/share-card.jpg' );
	$tags  = array(
		'og:site_name'   => get_bloginfo( 'name' ),
		'og:type'        => is_front_page() ? 'website' : 'article',
		'og:title'       => $title,
		'og:description' => wp_strip_all_tags( $desc ),
		'og:url'         => $url,
		'og:image'       => $image,
		'og:locale'      => 'en_GB',
	);
	foreach ( $tags as $property => $content ) {
		if ( $content ) {
			printf( '<meta property="%s" content="%s">' . "\n", esc_attr( $property ), esc_attr( $content ) );
		}
	}
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	echo '<meta name="twitter:site" content="@kbrt2013">' . "\n";
}
add_action( 'wp_head', 'kbrt_social_meta', 3 );
