<?php
/**
 * Title: Our story: impact by country and county
 * Slug: kbrt/story-impact
 * Categories: kbrt-sections
 * Keywords: impact, countries, counties, data
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"impact","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="impact" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"760px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Our impact</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">2,501 loved ones home from 88 countries, to all 32 counties.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Breakdowns from the KBRT 2026 fact sheet, when the total stood at 2,501. The latest total reported by the Trust is 2,612.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Where families needed us most</h3>
<!-- /wp:heading -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>Country</th><th class="has-text-align-right" data-align="right">Repatriations</th></tr></thead><tbody><tr><td>United Kingdom</td><td class="has-text-align-right" data-align="right">1,169</td></tr><tr><td>United States</td><td class="has-text-align-right" data-align="right">283</td></tr><tr><td>Spain</td><td class="has-text-align-right" data-align="right">256</td></tr><tr><td>Australia</td><td class="has-text-align-right" data-align="right">157</td></tr><tr><td>France</td><td class="has-text-align-right" data-align="right">51</td></tr><tr><td>Canada</td><td class="has-text-align-right" data-align="right">50</td></tr><tr><td>Portugal</td><td class="has-text-align-right" data-align="right">46</td></tr><tr><td>Germany</td><td class="has-text-align-right" data-align="right">43</td></tr><tr><td>Turkey</td><td class="has-text-align-right" data-align="right">37</td></tr><tr><td>Thailand</td><td class="has-text-align-right" data-align="right">36</td></tr></tbody></table><figcaption class="wp-element-caption">Top ten countries, of 88. Source: KBRT 2026 fact sheet.</figcaption></figure>
<!-- /wp:table --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Where we brought people home to</h3>
<!-- /wp:heading -->

<!-- wp:table {"hasFixedLayout":false,"className":"is-style-stripes"} -->
<figure class="wp-block-table is-style-stripes"><table><thead><tr><th>County</th><th class="has-text-align-right" data-align="right">Repatriations</th></tr></thead><tbody><tr><td>Dublin</td><td class="has-text-align-right" data-align="right">394</td></tr><tr><td>Antrim</td><td class="has-text-align-right" data-align="right">309</td></tr><tr><td>Cork</td><td class="has-text-align-right" data-align="right">169</td></tr><tr><td>Down</td><td class="has-text-align-right" data-align="right">154</td></tr><tr><td>Derry</td><td class="has-text-align-right" data-align="right">126</td></tr><tr><td>Limerick</td><td class="has-text-align-right" data-align="right">111</td></tr><tr><td>Mayo</td><td class="has-text-align-right" data-align="right">98</td></tr><tr><td>Galway</td><td class="has-text-align-right" data-align="right">97</td></tr><tr><td>Tyrone</td><td class="has-text-align-right" data-align="right">91</td></tr><tr><td>Armagh</td><td class="has-text-align-right" data-align="right">85</td></tr></tbody></table><figcaption class="wp-element-caption">Top ten counties, of 32. Source: KBRT 2026 fact sheet.</figcaption></figure>
<!-- /wp:table --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
