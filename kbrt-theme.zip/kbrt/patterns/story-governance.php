<?php
/**
 * Title: Our story: governance
 * Slug: kbrt/story-governance
 * Categories: kbrt-sections
 * Keywords: governance, trustees, accounts, regulator
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"governance","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="governance" class="wp-block-group alignfull has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Governance</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textColor":"paper"} -->
<h2 class="wp-block-heading has-paper-color has-text-color">Accountable in both jurisdictions</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mint-text"} -->
<p class="has-mint-text-color has-text-color">The Trust is led by volunteer trustees and a small staff team in Newry, and is regulated north and south.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:list {"className":"kbrt-ticks"} -->
<ul class="wp-block-list kbrt-ticks"><!-- wp:list-item -->
<li>Charity Commission for Northern Ireland: <strong>NIC100314</strong></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Charities Regulator, Ireland: <strong>RCN 20102937</strong></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Income in the year to 31 August 2025: <strong>£2,653,973</strong></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Spent directly on repatriation in that year: <strong>£1,234,850</strong></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Trustees: <strong>11 volunteers</strong></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-yellow"} -->
<div class="wp-block-button is-style-yellow"><a class="wp-block-button__link wp-element-button" href="https://www.charitycommissionni.org.uk/charity-details/?regId=100314">View our accounts on the charity register</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
