<?php
/**
 * Title: Donate: opening and donation routes (iDonate for euro, card form for sterling)
 * Slug: kbrt/donate-hero
 * Categories: kbrt-sections
 * Keywords: donate, form, give, idonate
 * Viewport Width: 1400
 */
$kbrt = kbrt_facts();
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"48%"} -->
<div class="wp-block-column" style="flex-basis:48%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Donate</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color">Help bring the next family’s loved one home.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mint-text","fontSize":"large"} -->
<p class="has-mint-text-color has-text-color has-large-font-size">The Trust is funded by donations. Your gift goes towards the cost of repatriation for families across Ireland.</p>
<!-- /wp:paragraph -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-photo-round"} -->
<figure class="wp-block-image size-full kbrt-photo-round"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/photo-carrick-a-rede.webp' ) ); ?>" alt="Carrick-a-Rede rope bridge on the Antrim coast"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"52%"} -->
<div class="wp-block-column" style="flex-basis:52%"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"white","textColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-ink-color has-white-background-color has-text-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:heading {"level":2,"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Make a donation</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Choose the currency you give in. Both routes are secure and go straight to the Trust.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Giving in euro</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Give once or monthly through iDonate, the Trust’s Irish donation partner.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-yellow"} -->
<div class="wp-block-button is-style-yellow"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $kbrt['idonate'] ); ?>">Donate in euro with iDonate</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:heading {"level":3,"fontSize":"large"} -->
<h3 class="wp-block-heading has-large-font-size">Giving in sterling</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Give by card on our secure donation form, with the option to add a message or give in memory of someone.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="<?php echo esc_url( $kbrt['gbp_form'] ); ?>">Donate in sterling</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">Prefer PayPal? <a href="<?php echo esc_url( $kbrt['paypal'] ); ?>">Donate with PayPal</a>. For a bank transfer, <a href="/contact/">contact us</a> and we will send the details.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","anchor":"donate-sterling","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"mist","layout":{"type":"constrained","contentSize":"760px"}} -->
<section id="donate-sterling" class="wp-block-group alignfull has-mist-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Donate in sterling</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Give by card</h2>
<!-- /wp:heading -->

<!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:html -->
<form class="kbrt-demo-form" data-kbrt-demo-form="donation" aria-label="Donate in sterling">
<fieldset><legend>Choose an amount</legend><div class="kbrt-pills"><input type="radio" id="dn-10" name="dn-amount" value="10"><label for="dn-10">£10</label><input type="radio" id="dn-20" name="dn-amount" value="20" checked><label for="dn-20">£20</label><input type="radio" id="dn-30" name="dn-amount" value="30"><label for="dn-30">£30</label><input type="radio" id="dn-other" name="dn-amount" value="other"><label for="dn-other">Other</label></div></fieldset>
<div class="kbrt-field"><label for="dn-other-amount">Other amount (£)</label><input type="number" id="dn-other-amount" name="dn-other-amount" min="1" step="1" inputmode="numeric"></div>
<div class="kbrt-field"><label for="dn-message">In memory of / message <span class="kbrt-optional">(optional)</span></label><textarea id="dn-message" name="dn-message" rows="4"></textarea></div>
<button type="submit">Continue to secure payment</button>
<p class="kbrt-note">Payments are processed securely by Stripe.</p>
</form>
<!-- /wp:html --></div>
<!-- /wp:group --></section>
<!-- /wp:group -->
