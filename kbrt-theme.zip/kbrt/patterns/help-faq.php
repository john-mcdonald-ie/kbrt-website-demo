<?php
/**
 * Title: Get help: questions families ask (adds FAQ structured data automatically)
 * Slug: kbrt/help-faq
 * Categories: kbrt-sections
 * Keywords: faq, questions, answers
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"questions","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="questions" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"36%"} -->
<div class="wp-block-column" style="flex-basis:36%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Questions families ask</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Clear answers, when you need them</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">If your question is not here, please call. There is no such thing as a wrong question.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"64%"} -->
<div class="wp-block-column" style="flex-basis:64%"><!-- wp:group {"className":"kbrt-faq","style":{"spacing":{"blockGap":"0"}},"layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-faq"><!-- wp:details -->
<details class="wp-block-details"><summary>Who can the Trust help?</summary><!-- wp:paragraph -->
<p>We help bereaved families living anywhere in the 32 counties of Ireland, north and south, regardless of background, religion or the circumstances of the death.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Do I need to contact the embassy first?</summary><!-- wp:paragraph -->
<p>No. You can call us directly. Irish embassies and consulates, through the Department of Foreign Affairs, also give families our details.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>How much does repatriation cost?</summary><!-- wp:paragraph -->
<p>It depends on the country and the arrangements. Costs range from about €1,600 to €18,000, and the average is about €6,000 to €7,000.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>What does the Trust pay for?</summary><!-- wp:paragraph -->
<p>We give financial assistance towards the cost of bringing your loved one home to Ireland. Assistance is paid once the costs are confirmed. We will explain exactly what we can cover when you call.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>What if there is travel insurance?</summary><!-- wp:paragraph -->
<p>Please tell us when you call. If the costs are later met by insurance or another source, the Trust may ask for its assistance to be repaid.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Can you help us bring ashes home?</summary><!-- wp:paragraph -->
<p>Yes. Our work includes helping families with cremation abroad and bringing ashes home to Ireland.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details -->

<!-- wp:details -->
<details class="wp-block-details"><summary>Does it matter how my loved one died?</summary><!-- wp:paragraph -->
<p>We help after any sudden or tragic death abroad, whatever the circumstances.</p>
<!-- /wp:paragraph --></details>
<!-- /wp:details --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
