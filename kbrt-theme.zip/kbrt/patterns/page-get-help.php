<?php
/**
 * Title: Page: Get help now
 * Slug: kbrt/page-get-help
 * Categories: kbrt-pages
 * Keywords: help, page
 * Block Types: core/post-content
 * Post Types: page
 * Template Types: page-designed
 * Viewport Width: 1400
 */
?>
<!-- wp:pattern {"slug":"kbrt/help-hero"} /-->

<!-- wp:pattern {"slug":"kbrt/help-anywhere"} /-->

<!-- wp:pattern {"slug":"kbrt/help-steps"} /-->

<!-- wp:pattern {"slug":"kbrt/help-who-cost"} /-->

<!-- wp:pattern {"slug":"kbrt/help-faq"} /-->

<!-- wp:pattern {"slug":"kbrt/help-callback"} /-->

<!-- wp:pattern {"slug":"kbrt/help-professionals"} /-->
