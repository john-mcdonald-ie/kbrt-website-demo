<?php
/**
 * Title: Donate: where your money goes
 * Slug: kbrt/donate-where-money-goes
 * Categories: kbrt-sections
 * Keywords: transparency, spending, accounts
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Where your money goes</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">98p in every pound we spend goes on bringing people home.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">In the year to 31 August 2025 the Trust spent £1,254,380. Of that, £1,234,850 went directly on repatriation, helping 290 people come home from 33 countries.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center"><!-- wp:html -->
<div class="kbrt-bar" role="img" aria-label="98.4 per cent of spending went on repatriation and 1.6 per cent on everything else"><span style="width:98.4%;background:#007A3F"></span><span style="width:1.6%;background:#EDB40C"></span></div>
<!-- /wp:html -->

<!-- wp:paragraph -->
<p>Repatriation 98.4% · Everything else 1.6%</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">Source: Trustees’ report and accounts for the year to 31 August 2025.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
