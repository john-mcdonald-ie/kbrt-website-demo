<?php
/**
 * Title: Donate: other ways to give
 * Slug: kbrt/donate-other-ways
 * Categories: kbrt-sections
 * Keywords: fundraise, bank transfer, memory, corporate
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"other-ways","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"backgroundColor":"mist","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="other-ways" class="wp-block-group alignfull has-mist-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Other ways to give</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Give in the way that suits you</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"1.75rem","bottom":"1.75rem","left":"1.75rem","right":"1.75rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Bank transfer</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Contact us and we will send the Trust’s sterling or euro account details.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="/contact/">Ask for bank details</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","anchor":"fundraise","style":{"spacing":{"padding":{"top":"1.75rem","bottom":"1.75rem","left":"1.75rem","right":"1.75rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div id="fundraise" class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Fundraise for us</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">The Trust does not run general fundraising itself, so events by individuals, clubs and businesses matter. Set up a page and tell us about it.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="<?php echo esc_url( kbrt_facts()['idonate_fundraise'] ); ?>">Start a page on iDonate (euro)</a><br><a href="<?php echo esc_url( kbrt_facts()['justgiving_fundraise'] ); ?>">Start a page on JustGiving (sterling)</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","anchor":"in-memory","style":{"spacing":{"padding":{"top":"1.75rem","bottom":"1.75rem","left":"1.75rem","right":"1.75rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div id="in-memory" class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Give in memory</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Remember someone special with a gift in their name, or ask for donations to the Trust in place of flowers.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"1.75rem","bottom":"1.75rem","left":"1.75rem","right":"1.75rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:1.75rem;padding-right:1.75rem;padding-bottom:1.75rem;padding-left:1.75rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Businesses and groups</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Companies, clubs and community groups can support the Trust through events, matched giving and donations.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="mailto:info@kevinbellrepatriationtrust.com">Email us</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">The Trust keeps a record of events advertised for its benefit. If you have a question or concern about fundraising that uses the name or logo of KBRT, please call us on +44 (0)28 3083 3311.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
