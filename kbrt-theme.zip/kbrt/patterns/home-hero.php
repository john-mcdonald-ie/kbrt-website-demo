<?php
/**
 * Title: Home: hero with help first
 * Slug: kbrt/home-hero
 * Categories: kbrt-sections
 * Keywords: hero, home, help
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|70"}}},"backgroundColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-paper-background-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Kevin Bell Repatriation Trust</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">When someone dies abroad, we help bring them home.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"large"} -->
<p class="has-muted-color has-text-color has-large-font-size">We give bereaved families in all 32 counties of Ireland financial help, practical support and advice after a sudden or tragic death overseas.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="tel:+442830833311">Call +44 (0)28 3083 3311</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/get-help/">How we can help</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">Registered charity in Northern Ireland (NIC100314) and Ireland (RCN 20102937)</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:50%"><!-- wp:group {"className":"kbrt-hero-art","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-hero-art"><!-- wp:columns {"isStackedOnMobile":false} -->
<div class="wp-block-columns is-not-stacked-on-mobile"><!-- wp:column {"width":"58%"} -->
<div class="wp-block-column" style="flex-basis:58%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-slant is-a"} -->
<figure class="wp-block-image size-full kbrt-slant is-a"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/photo-giants-causeway.webp' ) ); ?>" alt="Sunset over the Giant’s Causeway"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"54%"} -->
<div class="wp-block-column" style="flex-basis:54%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-slant is-b"} -->
<figure class="wp-block-image size-full kbrt-slant is-b"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/photo-cliffs-of-moher.webp' ) ); ?>" alt="The Cliffs of Moher above the Atlantic"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-goldfinch"} -->
<figure class="wp-block-image size-full kbrt-goldfinch"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/kbrt-goldfinch.webp' ) ); ?>" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
