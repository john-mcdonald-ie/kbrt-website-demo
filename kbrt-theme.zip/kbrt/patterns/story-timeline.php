<?php
/**
 * Title: Our story: timeline
 * Slug: kbrt/story-timeline
 * Categories: kbrt-sections
 * Keywords: timeline, history
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"backgroundColor":"mist","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-mist-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Since 2013</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">From seven families to thirty a month</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2013</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Kevin dies in New York. The Trust is founded in his memory and helps seven families in its first year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2015</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Registered with the Charity Commission for Northern Ireland.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2018</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Colin Bell receives a Points of Light award from the Prime Minister for the Trust’s work.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2020</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">The Trust opens a new centre in Newry.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2024/25</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">290 people brought home from 33 countries in a single year.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"textColor":"kevin-green","fontSize":"x-large","fontFamily":"display"} -->
<p class="has-kevin-green-color has-text-color has-display-font-family has-x-large-font-size">2026</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">Colin and Eithne step back from the day-to-day running. Director of Operations Diarmaid McAuley leads the team. 2,612 loved ones home.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
