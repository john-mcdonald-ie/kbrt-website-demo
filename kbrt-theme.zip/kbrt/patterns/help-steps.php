<?php
/**
 * Title: Get help: what happens when you call
 * Slug: kbrt/help-steps
 * Categories: kbrt-sections
 * Keywords: steps, process, how it works
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"how-it-works","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="how-it-works" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">How it works</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">What happens when you call</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:columns {"className":"kbrt-steps","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns kbrt-steps"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"kbrt-eyebrow","textColor":"gold-text"} -->
<p class="kbrt-eyebrow has-gold-text-color has-text-color">Step 1</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">We listen</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">We take the details of what has happened and where, and explain how we can help.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"kbrt-eyebrow","textColor":"gold-text"} -->
<p class="kbrt-eyebrow has-gold-text-color has-text-color">Step 2</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">We work with people abroad</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">We coordinate with funeral directors, the embassy or consulate and the local authorities.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"kbrt-eyebrow","textColor":"gold-text"} -->
<p class="kbrt-eyebrow has-gold-text-color has-text-color">Step 3</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">We arrange the journey</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">We arrange for your loved one to be brought home to any of the 32 counties.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"kbrt-eyebrow","textColor":"gold-text"} -->
<p class="kbrt-eyebrow has-gold-text-color has-text-color">Step 4</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">We help with the cost</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color">We give financial assistance towards the repatriation, paid once the costs are confirmed.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
