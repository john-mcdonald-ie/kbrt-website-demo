<?php
/**
 * Title: Page: Our story and impact
 * Slug: kbrt/page-our-story
 * Categories: kbrt-pages
 * Keywords: about, story, page
 * Block Types: core/post-content
 * Post Types: page
 * Template Types: page-designed
 * Viewport Width: 1400
 */
?>
<!-- wp:pattern {"slug":"kbrt/story-hero"} /-->

<!-- wp:pattern {"slug":"kbrt/story-timeline"} /-->

<!-- wp:pattern {"slug":"kbrt/story-impact"} /-->

<!-- wp:pattern {"slug":"kbrt/story-governance"} /-->

<!-- wp:pattern {"slug":"kbrt/quick-donate"} /-->
