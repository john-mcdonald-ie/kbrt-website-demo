<?php
/**
 * Title: Get help: call-back request
 * Slug: kbrt/help-callback
 * Categories: kbrt-sections
 * Keywords: form, call back, contact
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"callback","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="callback" class="wp-block-group alignfull has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Ask us to call you</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textColor":"paper"} -->
<h2 class="wp-block-heading has-paper-color has-text-color">Leave your number and we will ring you back.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mint-text"} -->
<p class="has-mint-text-color has-text-color">If it is urgent, please phone us on <a href="tel:+442830833311">+44 (0)28 3083 3311</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2.25rem","bottom":"2.25rem","left":"2.25rem","right":"2.25rem"}}},"backgroundColor":"paper","textColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-ink-color has-paper-background-color has-text-color has-background" style="padding-top:2.25rem;padding-right:2.25rem;padding-bottom:2.25rem;padding-left:2.25rem"><!-- wp:paragraph -->
<p><strong>Form goes here.</strong> Replace this paragraph with a Form block (Jetpack Form on WordPress.com). Fields: your name, phone number, country where your loved one died, best time to call, anything you would like us to know (optional), and a consent tick box linking to the privacy notice. Send submissions to info@kevinbellrepatriationtrust.com.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
