<?php
/**
 * Title: Get help: call-back request
 * Slug: kbrt/help-callback
 * Categories: kbrt-sections
 * Keywords: form, call back, contact
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"callback","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="callback" class="wp-block-group alignfull has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Ask us to call you</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textColor":"paper"} -->
<h2 class="wp-block-heading has-paper-color has-text-color">Leave your number and we will ring you back.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"textColor":"mint-text"} -->
<p class="has-mint-text-color has-text-color">If it is urgent, please phone us on <a href="tel:+442830833311">+44 (0)28 3083 3311</a>.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2.25rem","bottom":"2.25rem","left":"2.25rem","right":"2.25rem"}}},"backgroundColor":"paper","textColor":"ink","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-ink-color has-paper-background-color has-text-color has-background" style="padding-top:2.25rem;padding-right:2.25rem;padding-bottom:2.25rem;padding-left:2.25rem"><!-- wp:html -->
<form class="kbrt-demo-form" data-kbrt-demo-form="request" aria-label="Request a call back">
<div class="kbrt-field"><label for="cb-name">Your name</label><input type="text" id="cb-name" name="cb-name" autocomplete="name" required></div>
<div class="kbrt-field"><label for="cb-phone">Phone number</label><input type="tel" id="cb-phone" name="cb-phone" autocomplete="tel" required></div>
<div class="kbrt-field"><label for="cb-country">Country where your loved one died</label><input type="text" id="cb-country" name="cb-country" autocomplete="country-name" required></div>
<div class="kbrt-field"><label for="cb-time">Best time to call</label><select id="cb-time" name="cb-time"><option>As soon as possible</option><option>Morning</option><option>Afternoon</option><option>Evening</option></select></div>
<div class="kbrt-field"><label for="cb-message">Anything you would like us to know <span class="kbrt-optional">(optional)</span></label><textarea id="cb-message" name="cb-message" rows="4"></textarea></div>
<div class="kbrt-consent"><input type="checkbox" id="cb-consent" name="cb-consent" required><label for="cb-consent">I agree to the Trust using these details to reply to me, as set out in the <a href="/privacy-policy/">privacy notice</a>.</label></div>
<button type="submit">Request a call back</button>
</form>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
