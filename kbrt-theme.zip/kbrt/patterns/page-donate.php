<?php
/**
 * Title: Page: Donate
 * Slug: kbrt/page-donate
 * Categories: kbrt-pages
 * Keywords: donate, page
 * Block Types: core/post-content
 * Post Types: page
 * Template Types: page-designed
 * Viewport Width: 1400
 */
?>
<!-- wp:pattern {"slug":"kbrt/donate-hero"} /-->

<!-- wp:pattern {"slug":"kbrt/donate-where-money-goes"} /-->

<!-- wp:pattern {"slug":"kbrt/donate-other-ways"} /-->
