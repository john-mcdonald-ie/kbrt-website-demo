<?php
/**
 * Title: Shop: opening banner
 * Slug: kbrt/shop-intro
 * Categories: kbrt-sections
 * Keywords: shop, merchandise, jersey
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"backgroundColor":"kevin-green","textColor":"white","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-white-color has-kevin-green-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center"} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"58%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:58%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">The KBRT shop</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1,"textColor":"white"} -->
<h1 class="wp-block-heading has-white-color has-text-color">Wear the green and gold.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Official KBRT jerseys and polos by O’Neills, with the goldfinch and a map of the world in the design. Sold by KBRT Trading Limited, the Trust’s trading company.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"42%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:42%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-photo-round"} -->
<figure class="wp-block-image size-full kbrt-photo-round"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/product-jersey-front.webp' ) ); ?>" alt="The green KBRT jersey with gold band"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
