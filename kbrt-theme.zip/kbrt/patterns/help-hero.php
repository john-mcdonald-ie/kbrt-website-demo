<?php
/**
 * Title: Get help: opening and contact card
 * Slug: kbrt/help-hero
 * Categories: kbrt-sections
 * Keywords: help, contact, phone
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Get help now</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Someone you love has died abroad. We can help bring them home.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">We are so sorry. You do not have to work out what to do next on your own. Call us and we will explain how we can help, what happens next and what it may cost your family.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">We help families in all 32 counties of Ireland, whatever their background and whatever the circumstances of the death.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2.25rem","bottom":"2.25rem","left":"2.25rem","right":"2.25rem"}}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:2.25rem;padding-right:2.25rem;padding-bottom:2.25rem;padding-left:2.25rem"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Talk to us</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"className":"kbrt-bigphone","style":{"typography":{"fontSize":"2.25rem","lineHeight":"1.1"}},"fontFamily":"display"} -->
<p class="kbrt-bigphone has-display-font-family" style="font-size:2.25rem;line-height:1.1"><a href="tel:+442830833311">+44 (0)28 3083 3311</a></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"mint-text","fontSize":"small"} -->
<p class="has-mint-text-color has-text-color has-small-font-size">From the Republic of Ireland, dial 048 3083 3311.<br>[Opening hours and out-of-hours arrangements]</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-yellow"} -->
<div class="wp-block-button is-style-yellow"><a class="wp-block-button__link wp-element-button" href="tel:+442830833311">Call us now</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="#callback">Ask us to call you</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><a href="mailto:info@kevinbellrepatriationtrust.com">info@kevinbellrepatriationtrust.com</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"backgroundColor":"goldfinch","textColor":"forest","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-forest-color has-goldfinch-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--30)"><!-- wp:paragraph -->
<p><strong>If you are abroad right now,</strong> contact the nearest Irish embassy or consulate. If your loved one held a British passport, the British embassy or consulate can also help. You can call us at the same time; you do not need to wait.</p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
