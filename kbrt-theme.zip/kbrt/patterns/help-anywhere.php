<?php
/**
 * Title: Get help: wherever you are (share with family, time zones, calling from abroad)
 * Slug: kbrt/help-anywhere
 * Categories: kbrt-sections
 * Keywords: share, whatsapp, abroad, time zone
 * Viewport Width: 1400
 */
$kbrt  = kbrt_facts();
$share = home_url( $kbrt['help_path'] );
$msg   = rawurlencode( 'The Kevin Bell Repatriation Trust can help bring our loved one home. Their number is ' . $kbrt['phone_display'] . ' (from the Republic of Ireland ' . $kbrt['phone_roi'] . '). More here: ' . $share );
?>
<!-- wp:group {"tagName":"section","anchor":"wherever-you-are","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="wherever-you-are" class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Wherever you are</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Reaching us from abroad, and keeping your family in the loop</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|30"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"mist","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-mist-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Calling from another country</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Dial <a href="tel:+442830833311"><strong>+44 28 3083 3311</strong></a>. Leave out the 0 after +44.</p>
<!-- /wp:paragraph -->
<?php if ( ! empty( $kbrt['whatsapp'] ) ) : ?>

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://wa.me/<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $kbrt['whatsapp'] ) ); ?>">Message us on WhatsApp</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
<?php endif; ?>

<!-- wp:html -->
<p class="kbrt-clock" data-kbrt-clock>It is <strong data-kbrt-newry>now</strong> in Newry<span data-kbrt-local-wrap hidden> and <strong data-kbrt-local></strong> where you are</span>.</p>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"mist","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-mist-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Share this with your family</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Often one person makes the calls. Send everyone else our number and this page in one tap.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="https://wa.me/?text=<?php echo esc_attr( $msg ); ?>">Send by WhatsApp</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="mailto:?subject=<?php echo esc_attr( rawurlencode( 'Kevin Bell Repatriation Trust' ) ); ?>&amp;body=<?php echo esc_attr( $msg ); ?>">Send by email</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"mist","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-mist-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ask us to call you</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>If calling is difficult or expensive where you are, leave your number and the best time to reach you, and we will ring you.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-yellow"} -->
<div class="wp-block-button is-style-yellow"><a class="wp-block-button__link wp-element-button" href="#callback">Request a call back</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
