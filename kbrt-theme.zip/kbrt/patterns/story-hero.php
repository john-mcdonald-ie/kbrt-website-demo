<?php
/**
 * Title: Our story: Kevin's story
 * Slug: kbrt/story-hero
 * Categories: kbrt-sections
 * Keywords: story, kevin, about
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Our story</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Kevin’s legacy is every family we help bring home.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">On 16 June 2013, Kevin Bell, aged 26, died suddenly in New York. The people of Newry and beyond came together to raise the money to bring him home.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Kevin’s parents, Colin and Eithne Bell, and their family set up the Kevin Bell Repatriation Trust as a lasting memorial to him, so that other families would not have to face the same struggle alone.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-photo-round kbrt-kevin"} -->
<figure class="wp-block-image size-full kbrt-photo-round kbrt-kevin"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/photo-kevin-bell.webp' ) ); ?>" alt="Kevin Bell"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
