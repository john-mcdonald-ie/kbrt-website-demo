<?php
/**
 * Title: Kevin's legacy
 * Slug: kbrt/kevins-legacy
 * Categories: kbrt-sections
 * Keywords: story, kevin, founder
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center"><!-- wp:column {"verticalAlignment":"center","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:40%"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-photo-round kbrt-kevin"} -->
<figure class="wp-block-image size-full kbrt-photo-round kbrt-kevin"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/photo-kevin-bell.webp' ) ); ?>" alt="Kevin Bell"/></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"className":"kbrt-badge"} -->
<p class="kbrt-badge">Kevin Bell, 1986 to 2013</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"60%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:60%"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Kevin’s legacy</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">It began with one family and one journey home.</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Kevin Bell died suddenly in New York in June 2013. His community rallied to raise the money to bring him home to Newry.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">His parents, Colin and Eithne Bell, turned that kindness into a trust, so that no family in Ireland would face that journey alone. In its first year the Trust helped seven families. Today it helps around 30 a month.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link wp-element-button" href="/our-story/">Read our story</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
