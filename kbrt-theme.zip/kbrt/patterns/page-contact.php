<?php
/**
 * Title: Page: Contact
 * Slug: kbrt/page-contact
 * Categories: kbrt-pages
 * Keywords: contact, address, phone
 * Block Types: core/post-content
 * Post Types: page
 * Template Types: page-designed
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|60"}}},"layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull" style="padding-top:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Contact us</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">Talk to the Trust</h1>
<!-- /wp:heading -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":2,"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">If someone has died abroad</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Please phone us: <a href="tel:+442830833311">+44 (0)28 3083 3311</a><br>From the Republic of Ireland: 048 3083 3311</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":2,"fontSize":"x-large"} -->
<h2 class="wp-block-heading has-x-large-font-size">Everything else</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Email <a href="mailto:info@kevinbellrepatriationtrust.com">info@kevinbellrepatriationtrust.com</a><br>Kevin Bell Repatriation Trust<br>Unit 7 Whitegates Business Park, Killeavy Road<br>Newry, Co. Down BT35 6UA</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">[Office opening hours]</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem","left":"2rem","right":"2rem"}}},"backgroundColor":"mist","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-mist-background-color has-background" style="padding-top:2rem;padding-right:2rem;padding-bottom:2rem;padding-left:2rem"><!-- wp:html -->
<form class="kbrt-demo-form" data-kbrt-demo-form="message" aria-label="Send us a message">
<div class="kbrt-field"><label for="ct-name">Your name</label><input type="text" id="ct-name" name="ct-name" autocomplete="name" required></div>
<div class="kbrt-field"><label for="ct-email">Email address</label><input type="email" id="ct-email" name="ct-email" autocomplete="email" required></div>
<div class="kbrt-field"><label for="ct-phone">Phone number <span class="kbrt-optional">(optional)</span></label><input type="tel" id="ct-phone" name="ct-phone" autocomplete="tel"></div>
<div class="kbrt-field"><label for="ct-message">Your message</label><textarea id="ct-message" name="ct-message" rows="6" required></textarea></div>
<div class="kbrt-consent"><input type="checkbox" id="ct-consent" name="ct-consent" required><label for="ct-consent">I agree to the Trust using these details to reply to me, as set out in the <a href="/privacy-policy/">privacy notice</a>.</label></div>
<button type="submit">Send message</button>
</form>
<!-- /wp:html --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
