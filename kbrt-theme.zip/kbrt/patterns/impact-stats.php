<?php
/**
 * Title: Impact figures on Forest
 * Slug: kbrt/impact-stats
 * Categories: kbrt-sections
 * Keywords: stats, impact, numbers
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"blockGap":"var:preset|spacing|40"}},"backgroundColor":"forest","textColor":"paper","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section class="wp-block-group alignfull has-paper-color has-forest-background-color has-text-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Since 2013</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textColor":"paper"} -->
<h2 class="wp-block-heading has-paper-color has-text-color">Every number here is a family who did not have to face it alone.</h2>
<!-- /wp:heading --></div>
<!-- /wp:group -->

<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"className":"kbrt-stat__num"} -->
<p class="kbrt-stat__num">2,612</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>loved ones brought home</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"className":"kbrt-stat__num"} -->
<p class="kbrt-stat__num">88</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>countries worldwide</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"className":"kbrt-stat__num"} -->
<p class="kbrt-stat__num">32</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>counties of Ireland</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"className":"kbrt-stat"} -->
<div class="wp-block-column kbrt-stat"><!-- wp:paragraph {"className":"kbrt-stat__num"} -->
<p class="kbrt-stat__num">98%</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>of our 2024/25 spending went directly on repatriation</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:heading {"level":3,"textColor":"paper"} -->
<h3 class="wp-block-heading has-paper-color has-text-color">Home from all over the world</h3>
<!-- /wp:heading -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","className":"kbrt-world-map"} -->
<figure class="wp-block-image size-full kbrt-world-map"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/images/world-map-dark.svg' ) ); ?>" alt="World map with the 88 countries the Trust has brought people home from shaded green, and lines from the twelve most common countries to Ireland"/><figcaption class="wp-element-caption">Shaded: the 88 countries families have needed us in. Lines: the twelve most common after the UK, which accounts for 1,169 repatriations on its own.</figcaption></figure>
<!-- /wp:image -->

<!-- wp:paragraph {"textColor":"mint-text","fontSize":"small"} -->
<p class="has-mint-text-color has-text-color has-small-font-size">Total as reported by KBRT, October 2026. Countries and counties from the KBRT 2026 fact sheet. Spending from the Trust’s accounts for the year to 31 August 2025.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p><a href="/our-story/#impact">See where families have been helped</a></p>
<!-- /wp:paragraph --></section>
<!-- /wp:group -->
