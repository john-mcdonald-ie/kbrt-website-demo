<?php
/**
 * Title: Get help: who we help and what it costs
 * Slug: kbrt/help-who-cost
 * Categories: kbrt-sections
 * Keywords: eligibility, cost, criteria
 * Viewport Width: 1400
 */
?>
<!-- wp:group {"tagName":"section","anchor":"who-we-help","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"}}},"backgroundColor":"mist","layout":{"type":"constrained","contentSize":"1200px"}} -->
<section id="who-we-help" class="wp-block-group alignfull has-mist-background-color has-background" style="padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">Who we can help</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">Any family in Ireland</h2>
<!-- /wp:heading -->

<!-- wp:list {"className":"kbrt-ticks"} -->
<ul class="wp-block-list kbrt-ticks"><!-- wp:list-item -->
<li>Families living anywhere in the 32 counties, north and south</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Whatever your background or religion</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>After a sudden or tragic death in any country, including the UK</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Whatever the circumstances of the death</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"className":"kbrt-card","style":{"spacing":{"padding":{"top":"2.25rem","bottom":"2.25rem","left":"2.25rem","right":"2.25rem"}}},"backgroundColor":"white","layout":{"type":"default"}} -->
<div class="wp-block-group kbrt-card has-white-background-color has-background" style="padding-top:2.25rem;padding-right:2.25rem;padding-bottom:2.25rem;padding-left:2.25rem"><!-- wp:paragraph {"className":"kbrt-eyebrow"} -->
<p class="kbrt-eyebrow">What it costs</p>
<!-- /wp:paragraph -->

<!-- wp:heading -->
<h2 class="wp-block-heading">€6,000 to €7,000 on average</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Bringing someone home can cost from about €1,600 to €18,000, depending on the country and the arrangements. Repatriations from the UK are usually at the lower end.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>The Trust gives financial assistance towards these costs, so that money is not what stands between a family and bringing their loved one home.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
